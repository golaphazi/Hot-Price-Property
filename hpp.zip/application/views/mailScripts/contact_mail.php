<div>
    <h4> Author Name : <?php echo $admin_full_name; ?> </h4>
    <h5> Subject : <?php echo $subject; ?> </h5>
    <h5> Contact Name : <?php echo $contact_name; ?></h5>
    <h6> Contact Email : <?php echo $contact_email; ?></h6> <b/>
    
    <div> Contact Message : <?php echo $contact_message; ?> </div>
</div>