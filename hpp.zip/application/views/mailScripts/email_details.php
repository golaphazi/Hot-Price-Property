
<div>
   <div> Contact Message : <?php echo $message_body; ?> </div>
</div>
