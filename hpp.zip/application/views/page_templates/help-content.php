<div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title">Help Page</h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header -->
        

        <!-- property area -->
        <div class="content-area recent-property" style="background-color: #FCFCFC; padding-bottom: 55px;">
            <div class="container">    

                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12 text-center page-title">
                        <!-- /.feature title -->
                        <h2> Help for (Seller & Buyer) </h2>
                        <br>
                    </div>
                </div>

                <div class="row row-feat"> 
                    <div class="col-md-6">
                       <h5>1. Create Seller Account with Add new Property & Dashboard </h5>
                       <iframe style="width:100%; height:360px;" src="https://www.youtube.com/embed/9M-KnVqpiEo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                             
                    </div>
					<div class="col-md-6">
                       <h5>2. Manage Auction Property For Seller Account </h5>
                      <iframe style="width:100%; height:360px;"  src="https://www.youtube.com/embed/AwZAshdxb-g" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>     
                    </div>
					<div class="col-md-6">
                       <h5>3. Create Buyer Account with Join Auction </h5>
						<iframe style="width:100%; height:360px;"  src="https://www.youtube.com/embed/yaaOJRbPRc4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
					  </div>
                </div>
                
            </div>
        </div>