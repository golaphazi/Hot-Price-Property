


<div class="container" style="padding: 70px 0;">
    <div class="row">
        <div class="col-xs-12">
            <div id="actioMessage">
                <div class="alert alert-success">
                    <?php echo 'Add Property Information SuccessFully..!'; ?>
                </div>   
            </div>    
        </div> <!-- End of col-xs-12 --><br/>
        <div class="col-xs-12"><h6>N.B : Payment Process is under development...!</h6></div>
    </div> <!-- End of row-->
</div>