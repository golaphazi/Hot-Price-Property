<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Description of AuctionPaymentControll
 *
 * @author HPP
 */
class AuctionPaymentControll extends HPP_Controller{
    //put your code here
    public function paymentIndex(){ 
       $data = array();
       $data['title'] = 'Auction Payment';
       $data['main_content'] = $this->load->view('page_templates/dashboard/users/property/auction_payment_process', $data, TRUE );
       $this->load->view( 'master', $data );
       
    }
    
    
    
}
